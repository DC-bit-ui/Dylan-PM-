# Task: add three catchment layers to Frontier

Everything needed is in this folder. `FRONTIER-LAYERS.md` has the reasoning behind the styling and the data decisions; read it if a choice here looks arbitrary.

## Goal

A field agent working a lead anywhere in Australia can click the map and see which carbon and water credit instruments that catchment can carry. Frontier is a recruitment tool, so the layers exist to answer *what can I tell this landholder*, not to make a national statement.

## Files

| File | What it is |
|---|---|
| `frontier-catchments.geojson` | 219 polygons, every river region in Australia. The identify layer, carries the full attribute set |
| `frontier-acwis.geojson` | 12 polygons. Display layer for ACWIS catchments |
| `frontier-reef-credits.geojson` | 8 polygons. Display layer for Reef Credit catchments |
| `frontier-map-style.json` | Mapbox GL sources and layer definitions, ready to use |
| `FRONTIER-LAYERS.md` | Field dictionary, palette rationale, data caveats |
| `frontier-layers-preview.png` | What the result should look like, national and at working zoom. Reference for the marks, not the typography |

Geometry is the Bureau of Meteorology Australian Hydrological Geospatial Fabric, River Regions v3.3, coastline clipped and simplified for web rendering.

## What to build

1. **Register the three sources** from `frontier-map-style.json`. Set `promoteId: "label"` on the catchments source so hover and click state work per feature. `label` is unique across all 219.

   Insert the new layers **below** the existing landholder marker layers so property and prospect dots stay on top. Catchment layers are context; the markers are the thing agents are working with.

2. **Add the layers in the order given in the JSON.** Fills first, then lines, then symbols. Order matters: the neutral catchment reference line must sit above the scheme fills so boundaries stay readable through them.

3. **Wire the popup** on the catchments layer:

   ```
   {label}
   {instruments}
   {water_status}
   ```

   `water_status` is null on catchments with no scheme, so the popup needs to drop the line rather than render "null".

4. **Add them to the existing Layers control panel**, bottom right of the map. It currently has two groups: `BASE MAP` with radio buttons (Satellite, Hybrid, Street Map) and `LANDHOLDERS` with checkboxes (Projects, Prospects).

   Add a third group below LANDHOLDERS, following the LANDHOLDERS pattern exactly - same section label styling, same checkbox control, since these are independent toggles rather than a single choice:

   ```
   CATCHMENTS
   [ ] Catchments        -> catchments-line, catchments-label
   [ ] Reef Credits      -> reef-fill, reef-line
   [ ] ACWIS             -> acwis-fill, acwis-line
   ```

   **All three off by default.** Frontier is a live tool and a layer that arrives switched on changes every agent's map without them asking for it. Opt in, not opt out. If the team would rather it be discoverable on first load, that is their call to make, not a default to assume.

   Toggling a checkbox sets `visibility` on that group's layers. State should persist the same way the LANDHOLDERS toggles already do.

5. **Label behaviour.** Catchment names from about zoom 5, scheme names as a smaller offset label from about zoom 6. `text-allow-overlap` stays false so dense areas thin out rather than pile up. If 219 labels crowd at low zoom, filter the label layer on `carbon` or `water_scheme` at low zoom and release the full set higher up.

## Acceptance criteria

- [ ] The three new toggles appear under a `CATCHMENTS` group in the Layers panel, styled to match `LANDHOLDERS`, and all start unchecked
- [ ] Toggling each one shows and hides only its own layers, and the existing Projects and Prospects toggles are unaffected
- [ ] Clicking any point in Australia returns a catchment name and its instruments, including catchments with no scheme
- [ ] Property boundaries and imagery stay readable through the scheme fills at working zoom. If they do not, drop `fill-opacity` to 0 and let the strokes carry it
- [ ] Reef Credits reads as a solid line, ACWIS as a dashed line. This is the live market versus method only distinction and it should be visible without a legend
- [ ] Labels do not overlap at any zoom between 4 and 14
- [ ] `water_status` text appears in the popup for all 20 scheme catchments

## Constraints

**Do not merge Reef Credits and ACWIS into one water layer or one figure.** Different schemes, different geographies, different maturity.

**Do not restyle the palette.** The three colours are validated for colour blind separation against Frontier's dark surface.

**Do not join these to other datasets on the bare catchment name without checking.** There are two Fitzroys in Australia and two Marys. These files use `Fitzroy (Qld)` and `Mary (Qld)`. A join on "Fitzroy" will either fail or quietly match a catchment in Western Australia.

**Australian English throughout**, and no em dashes in any user facing copy.

## One data note

The 12 ACWIS catchments are AgriProve's own assessment, not a published scheme boundary, and the `water_status` field carries that wording per feature. It has to appear in the popup rather than being dropped for space.
